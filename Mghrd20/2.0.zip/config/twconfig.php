<?php
#################################################
// ahmed almalki
// 0543347557
// protop96@gmail.com
// http://waseethost.com/
#################################################

// معلومات التطبيق من تويتر    https://dev.twitter.com/apps

define('YOUR_CONSUMER_KEY', 'yl8JdiLui0aEORuIxCkzA'); // Consumer key
define('YOUR_CONSUMER_SECRET', 'l7cs7JXypeZRt1kBzYUAlKmBZVOwsQUnouzdmRi8Ks');  //CONSUMER_SECRET
define('REDIRECTED', 'http://127.0.0.1/AuTa/tw2/getTwitterData.php'); //مسار getTwitterData كامل


#################################################
// ahmed almalki
// 0543347557
// protop96@gmail.com
// http://waseethost.com/
#################################################
?>
